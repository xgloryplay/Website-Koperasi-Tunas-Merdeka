<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#103d2b">
    <meta name="description" content="Koperasi Tunas Merdeka — Bertumbuh Bersama, Sejahtera Bersama.">
    <title>@yield('title', 'Koperasi Tunas Merdeka')</title>
    <link rel="stylesheet" href="{{ asset('css/site.css') }}?v=1">
</head>
<body>
    @include('components.public-header')
    <main>@yield('content')</main>
    @include('components.public-footer')
</body>
</html>
