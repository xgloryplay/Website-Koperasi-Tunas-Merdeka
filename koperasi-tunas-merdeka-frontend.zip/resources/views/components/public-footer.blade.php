<footer class="site-footer">
    <div class="container footer-grid">
        <div class="footer-brand">
            <div class="brand brand-light"><span class="brand-mark">TM</span><span class="brand-copy">KOPERASI TUNAS MERDEKA<small>BERTUMBUH BERSAMA</small></span></div>
            <p>Membangun masa depan yang lebih baik melalui kebersamaan, kepercayaan, dan tata kelola yang bertanggung jawab.</p>
        </div>
        <div><h3>Jelajahi</h3><a href="{{ route('about') }}">Tentang Kami</a><a href="{{ route('services') }}">Produk &amp; Layanan</a><a href="{{ route('membership') }}">Keanggotaan</a></div>
        <div><h3>Informasi</h3><a href="{{ route('news') }}">Berita</a><a href="{{ route('publications') }}">Publikasi</a><a href="{{ route('contact') }}">Kontak</a></div>
    </div>
    <div class="container footer-bottom">© {{ date('Y') }} Koperasi Tunas Merdeka. Informasi resmi mengikuti ketentuan koperasi.</div>
</footer>
