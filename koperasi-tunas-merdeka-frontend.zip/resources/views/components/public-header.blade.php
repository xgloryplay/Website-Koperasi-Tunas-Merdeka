<header class="site-header">
    <div class="container nav-wrap">
        <a href="{{ route('home') }}" class="brand">
            <span class="brand-mark">TM</span>
            <span class="brand-copy">KOPERASI TUNAS MERDEKA<small>BERTUMBUH BERSAMA</small></span>
        </a>
        <nav class="nav-links" aria-label="Navigasi utama">
            <a href="{{ route('home') }}">Beranda</a>
            <a href="{{ route('about') }}">Tentang Kami</a>
            <a href="{{ route('services') }}">Produk &amp; Layanan</a>
            <a href="{{ route('membership') }}">Keanggotaan</a>
            <a href="{{ route('news') }}">Berita</a>
            <a href="{{ route('publications') }}">Publikasi</a>
            <a href="{{ route('contact') }}">Kontak</a>
        </nav>
        <a class="nav-cta" href="{{ route('login') }}">Portal Anggota <span>↗</span></a>
    </div>
</header>
