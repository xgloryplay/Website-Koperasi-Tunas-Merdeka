@extends('layouts.public')

@section('title', 'Beranda | Koperasi Tunas Merdeka')

@section('content')
<section class="hero">
    <div class="hero-orbit hero-orbit-one"></div><div class="hero-orbit hero-orbit-two"></div>
    <div class="container hero-inner">
        <div class="hero-copy">
            <span class="eyebrow"><span class="eyebrow-line"></span> KOPERASI TUNAS MERDEKA</span>
            <h1>Bertumbuh Bersama,<br><em>Sejahtera Bersama.</em></h1>
            <p>Membangun masa depan yang lebih baik melalui semangat kebersamaan, pelayanan profesional, dan pengelolaan koperasi yang bertanggung jawab.</p>
            <div class="hero-actions">
                <a href="{{ route('membership') }}" class="btn btn-gold">Informasi Keanggotaan <span>↗</span></a>
                <a href="{{ route('about') }}" class="btn btn-ghost">Kenali Koperasi</a>
            </div>
        </div>
        <div class="hero-art" aria-hidden="true">
            <div class="hero-art-ring"></div>
            <div class="hero-monogram">TM</div>
            <div class="hero-art-caption"><span>BERSAMA</span><b>Lebih Kuat</b><small>KEBERSAMAAN · KEPERCAYAAN · KEBERLANJUTAN</small></div>
        </div>
    </div>
    <div class="hero-bottom container"><span>01 — KEBERSAMAAN</span><span>MEMBANGUN NILAI, MENUMBUHKAN HARAPAN</span></div>
</section>

<section class="intro-section section">
    <div class="container intro-grid">
        <div><span class="section-kicker">TENTANG KAMI</span><h2>Kekuatan koperasi ada pada <em>kebersamaan.</em></h2></div>
        <div class="intro-copy"><p>Koperasi Tunas Merdeka hadir dengan semangat gotong royong untuk membangun ekosistem ekonomi yang mengutamakan anggota. Kami percaya pertumbuhan yang baik dibangun melalui kepercayaan, partisipasi, dan tata kelola yang bertanggung jawab.</p><a class="text-link" href="{{ route('about') }}">Mengenal koperasi kami <span>↗</span></a></div>
    </div>
</section>

<section class="values-section section">
    <div class="container">
        <div class="section-heading"><div><span class="section-kicker">NILAI KAMI</span><h2>Prinsip yang <em>menumbuhkan.</em></h2></div><p>Landasan dalam membangun hubungan dan pelayanan kepada anggota.</p></div>
        <div class="value-grid">
            <article class="value-card"><span class="value-number">01 / KEBERSAMAAN</span><div class="value-symbol">✳</div><h3>Tumbuh Bersama</h3><p>Semangat saling mendukung sebagai dasar kehidupan koperasi.</p></article>
            <article class="value-card"><span class="value-number">02 / KEPERCAYAAN</span><div class="value-symbol">◇</div><h3>Terbuka &amp; Terpercaya</h3><p>Mendorong pengelolaan yang transparan dan bertanggung jawab.</p></article>
            <article class="value-card"><span class="value-number">03 / KEBERLANJUTAN</span><div class="value-symbol">↗</div><h3>Manfaat Berkelanjutan</h3><p>Mengutamakan manfaat jangka panjang bagi anggota.</p></article>
        </div>
    </div>
</section>

<section class="services-section section">
    <div class="container">
        <div class="section-heading"><div><span class="section-kicker">PRODUK &amp; LAYANAN</span><h2>Layanan untuk <em>anggota.</em></h2></div><a class="text-link" href="{{ route('services') }}">Lihat semua layanan ↗</a></div>
        <div class="service-grid">
            <article class="service-card"><div class="service-icon">S</div><h3>Simpanan</h3><p>Informasi layanan simpanan dan administrasi keanggotaan.</p></article>
            <article class="service-card"><div class="service-icon">P</div><h3>Pinjaman</h3><p>Informasi fasilitas pinjaman sesuai ketentuan koperasi.</p></article>
            <article class="service-card"><div class="service-icon">A</div><h3>Layanan Anggota</h3><p>Akses informasi dan layanan melalui portal anggota.</p></article>
        </div>
    </div>
</section>

<section class="closing-section">
    <div class="container closing-inner"><div><span class="section-kicker">MELANGKAH BERSAMA</span><h2>Masa depan yang lebih baik<br><em>dibangun bersama.</em></h2></div><a href="{{ route('membership') }}" class="btn btn-gold">Pelajari Keanggotaan ↗</a></div>
</section>
@endsection
