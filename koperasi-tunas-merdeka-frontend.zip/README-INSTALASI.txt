PAKET FRONTEND KOPERASI TUNAS MERDEKA
=====================================

Isi ZIP ini adalah paket pengganti tampilan frontend publik, bukan seluruh aplikasi Laravel.

CARA PASANG DI GITHUB CODESPACES
1. Buat backup folder berikut jika sudah ada:
   resources/views/layouts/
   resources/views/components/
   resources/views/public/
   public/css/

2. Ekstrak isi ZIP ke ROOT proyek Laravel:
   /workspaces/Website-Koperasi-Tunas-Merdeka/

3. Pilih Replace/Overwrite jika diminta.
   Jangan hapus folder app, database, routes, vendor, node_modules, atau .env.

4. Pastikan routes/web.php memiliki route bernama:
   home, about, services, membership, news, publications, contact, login

5. Jika route login belum tersedia, ubah tautan route('login') pada:
   resources/views/components/public-header.blade.php
   menjadi href="/login" atau tautan login yang memang tersedia di aplikasi.

6. Jalankan:
   php artisan optimize:clear

7. Buka website lewat tab Ports pada Codespaces, port 8000.

CATATAN
- CSS dimuat langsung dari public/css/site.css, tidak membutuhkan Vite untuk stylesheet publik.
- Halaman beranda, header, footer, dan layout publik disediakan di paket ini.
- Halaman Tentang, Layanan, Keanggotaan, Berita, Publikasi, dan Kontak yang sudah ada tetap dipertahankan.
- Tampilan halaman lain akan mengikuti CSS sejauh memakai kelas yang tercakup stylesheet.
- Logo TM hanyalah placeholder, bukan logo resmi koperasi.
- Tidak ada data alamat, kontak, statistik, atau kebijakan resmi yang dikarang.
